export const SAMPLE_PESTS = [
  {
    id: 1,
    name: 'Aphids',
    crops: ['Wheat','Tomato','Potato'],
    symptoms: ['Curling leaves','Sticky residue','Stunted growth'],
    severity: 'Medium',
    treatments: [
      { name: 'Neem Oil', type: 'Bio-insecticide', dosage: '5 ml/L', notes: 'Repeat weekly' },
      { name: 'Pyrethrin Spray', type: 'Insecticide', dosage: '2 ml/L' }
    ]
  },
  {
    id: 2,
    name: 'Late Blight',
    crops: ['Tomato','Potato'],
    symptoms: ['Brown lesions','White fuzzy growth','Water-soaked spots'],
    severity: 'High',
    treatments: [ { name: 'Mancozeb', type: 'Fungicide', dosage: '3 g/L', notes: 'Rotate actives' } ]
  },
  {
    id: 3,
    name: 'Powdery Mildew',
    crops: ['Wheat','Tomato'],
    symptoms: ['White powder on leaves','Distorted leaves'],
    severity: 'Low',
    treatments: [ { name: 'Sulfur Wettable Powder', type: 'Fungicide', dosage: '4 g/L' } ]
  }
]

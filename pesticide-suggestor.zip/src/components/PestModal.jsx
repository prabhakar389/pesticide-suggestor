import React from 'react'

export default function PestModal({ activePest, onClose }){
  if(!activePest) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative max-w-3xl w-full bg-white rounded-2xl p-6 shadow-lg z-10">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-bold">{activePest.name}</h3>
            <p className="text-sm text-gray-500">Severity: {activePest.severity}</p>
          </div>
          <div><button onClick={onClose} className="p-2 rounded hover:bg-gray-100">✕</button></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold">Symptoms</h4>
            <ul className="list-disc list-inside mt-2 text-sm text-gray-700">{activePest.symptoms.map(s=> <li key={s}>{s}</li>)}</ul>
            <h4 className="font-semibold mt-4">Affected crops</h4>
            <div className="flex flex-wrap mt-2">{activePest.crops.map(c=> <span key={c} className="px-2 py-1 mr-2 mb-2 rounded bg-gray-100 text-sm">{c}</span>)}</div>
          </div>
          <div>
            <h4 className="font-semibold">Recommended treatments</h4>
            <div className="space-y-3 mt-2">{activePest.treatments.map(t => (
              <div key={t.name} className="p-3 border rounded">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="font-semibold">{t.name}</div>
                    <div className="text-xs text-gray-500">{t.type} • Dosage: {t.dosage}</div>
                  </div>
                  <div><button className="px-3 py-1 rounded bg-green-600 text-white text-sm">Apply</button></div>
                </div>
                {t.notes && <div className="text-xs text-gray-600 mt-2">Note: {t.notes}</div>}
              </div>
            ))}</div>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3"><button onClick={onClose} className="px-4 py-2 border rounded">Close</button></div>
      </div>
    </div>
  )
}

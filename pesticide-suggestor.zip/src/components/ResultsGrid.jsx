import React from 'react'

export default function ResultsGrid({ results, setActivePest, loading }){
  return (
    <div className="md:col-span-2">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500">{loading ? 'Loading...' : `${results.length} result(s)`}</p>
          <h2 className="text-xl font-semibold mt-1">Suggested matches</h2>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {!loading && results.length === 0 && (
          <div className="p-6 bg-white rounded-2xl border text-center col-span-full"><p className="text-gray-600">No pests found.</p></div>
        )}

        {results.map(p => (
          <article key={p.id} className="p-4 bg-white rounded-2xl shadow-sm border">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold">{p.name}</h3>
                <p className="text-xs text-gray-500 mt-1">Severity: <strong>{p.severity}</strong></p>
                <div className="mt-2 flex flex-wrap">{p.symptoms.slice(0,3).map(s => <span key={s} className="text-xs px-2 py-1 mr-2 mb-2 rounded bg-gray-100">{s}</span>)}</div>
              </div>
              <div className="text-right">
                <button onClick={()=>setActivePest(p)} className="px-3 py-2 rounded-lg bg-green-600 text-white text-sm">View</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

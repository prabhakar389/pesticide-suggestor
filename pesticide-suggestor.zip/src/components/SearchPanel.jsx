import React from 'react'

export default function SearchPanel({
  crop, setCrop, allCrops, search, setSearch,
  allSymptoms, selectedSymptoms, toggleSymptom,
  severityFilter, toggleSeverity, clearFilters, exportCSV
}) {
  return (
    <aside className="md:col-span-1 bg-white p-4 rounded-2xl shadow-sm border">
      <label className="block text-xs text-gray-600 mb-2">Crop</label>
      <select value={crop} onChange={e=>setCrop(e.target.value)} className="w-full border rounded px-3 py-2 mb-3">
        <option value="">-- Any crop --</option>
        {allCrops.map(c=> <option key={c} value={c}>{c}</option>)}
      </select>

      <label className="block text-xs text-gray-600 mb-2">Search pests or symptoms</label>
      <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="e.g. white powder, aphid" className="w-full border rounded px-3 py-2 mb-3" />

      <label className="block text-xs text-gray-600 mb-2">Symptoms</label>
      <div className="flex flex-wrap gap-2 max-h-40 overflow-auto mb-3">
        {allSymptoms.map(sym => (
          <button key={sym} onClick={()=>toggleSymptom(sym)} className={`text-sm px-3 py-1 rounded-full border ${selectedSymptoms.includes(sym)?'bg-green-600 text-white':'bg-white text-gray-700'}`}>{sym}</button>
        ))}
      </div>

      <label className="block text-xs text-gray-600 mb-2">Severity</label>
      <div className="flex gap-2 mb-3">
        {['Low','Medium','High'].map(s=> (
          <button key={s} onClick={()=>toggleSeverity(s)} className={`px-3 py-1 rounded ${severityFilter.includes(s)?'bg-green-600 text-white':'border'}`}>{s}</button>
        ))}
      </div>

      <div className="mt-4">
        <button onClick={clearFilters} className="px-3 py-2 rounded border">Clear</button>
        <button onClick={exportCSV} className="px-3 py-2 rounded border ml-2">Export</button>
      </div>

    </aside>
  )
}

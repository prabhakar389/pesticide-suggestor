import React, { useMemo, useState } from 'react'
import { SAMPLE_PESTS } from './data/pests'
import SearchPanel from './components/SearchPanel'
import ResultsGrid from './components/ResultsGrid'
import PestModal from './components/PestModal'

export default function App(){
  const [crop, setCrop] = useState('')
  const [search, setSearch] = useState('')
  const [selectedSymptoms, setSelectedSymptoms] = useState([])
  const [severityFilter, setSeverityFilter] = useState([])
  const [activePest, setActivePest] = useState(null)

  const allCrops = useMemo(()=>{
    const s = new Set(); SAMPLE_PESTS.forEach(p=>p.crops.forEach(c=>s.add(c))); return Array.from(s).sort()
  },[])

  const allSymptoms = useMemo(()=>{
    const s = new Set(); SAMPLE_PESTS.forEach(p=>p.symptoms.forEach(x=>s.add(x))); return Array.from(s).sort()
  },[])

  function toggleSymptom(sym){ setSelectedSymptoms(prev=> prev.includes(sym)? prev.filter(x=>x!==sym) : [...prev,sym]) }
  function toggleSeverity(s){ setSeverityFilter(prev=> prev.includes(s)? prev.filter(x=>x!==s) : [...prev,s]) }
  function clearFilters(){ setCrop(''); setSearch(''); setSelectedSymptoms([]); setSeverityFilter([]) }

  const results = useMemo(()=>{
    const q = search.trim().toLowerCase()
    return SAMPLE_PESTS.filter(p=>{
      if(crop && !p.crops.includes(crop)) return false
      if(severityFilter.length && !severityFilter.includes(p.severity)) return false
      if(q){ const text = `${p.name} ${p.symptoms.join(' ')}`.toLowerCase(); if(!text.includes(q)) return false }
      if(selectedSymptoms.length) for(let s of selectedSymptoms) if(!p.symptoms.includes(s)) return false
      return true
    })
  },[crop,search,selectedSymptoms,severityFilter])

  function exportCSV(){
    const headers = ['Pest','Severity','Crops','Symptoms','Treatments']
    const rows = results.map(r=>[
      r.name,
      r.severity,
      r.crops.join(' | '),
      r.symptoms.join(' | '),
      r.treatments.map(t=>`${t.name} (${t.type} ${t.dosage})`).join(' ; ')
    ])
    const csv = [headers.join(','), ...rows.map(r=> r.map(c=> `"${String(c).replace(/"/g,'""')}"`).join(',') )].join('
')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `pesticide-suggestions-${new Date().toISOString().slice(0,10)}.csv`; a.click(); URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div><h1 className="text-2xl font-extrabold">Pesticide Suggestor</h1><p className="text-sm text-gray-600">Find likely pests & recommended treatments</p></div>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <SearchPanel
            crop={crop} setCrop={setCrop} allCrops={allCrops}
            search={search} setSearch={setSearch}
            allSymptoms={allSymptoms} selectedSymptoms={selectedSymptoms} toggleSymptom={toggleSymptom}
            severityFilter={severityFilter} toggleSeverity={toggleSeverity}
            clearFilters={clearFilters} exportCSV={exportCSV}
          />

          <ResultsGrid results={results} setActivePest={setActivePest} loading={false} />
        </main>

        <PestModal activePest={activePest} onClose={()=>setActivePest(null)} />

      </div>
    </div>
  )
}
